<?php /* E:\MS-Master\Projects\FrameworkPHP\MS-Frame_5_8\Master\vendor\msllp\core\src\Views/panel.blade.php */ ?>
<?php $__env->startSection('page_heading','Panels and Collapsibles'); ?>

<?php $__env->startSection('section'); ?>
	<div class="col-sm-6">
		<?php $__env->startSection('panel1_panel_title', 'Default title'); ?>
		<?php $__env->startSection('panel1_panel_body'); ?>
		Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
		tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
		quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
		consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
		cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
		proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
		<?php $__env->stopSection(); ?>
		<?php echo $__env->make('MS::widgets.panel', array('header'=>true, 'as'=>'panel1'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<?php $__env->startSection('panel2_panel_title', 'Inverse Header'); ?>
		<?php $__env->startSection('panel2_panel_body'); ?>
		Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
		 tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
		 quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
		 consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
		 cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
		 proident, sunt in culpa qui officia deserunt mollit anim id est laborum. 
		<?php $__env->stopSection(); ?>
		<?php echo $__env->make('MS::widgets.panel', array('class'=>'primary', 'header'=>true, 'as'=>'panel2'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<?php $__env->startSection('panel3_panel_title', 'Header'); ?>
		<?php $__env->startSection('panel3_panel_body'); ?>
		Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
		tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
		quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
		consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
		cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
		proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
		<?php $__env->stopSection(); ?>
		<?php $__env->startSection('panel3_panel_footer', 'Footer'); ?>
		<?php echo $__env->make('MS::widgets.panel', array('class'=>'success', 'header'=>true, 'footer'=>true, 'as'=>'panel3'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	</div>
	<div class="col-sm-6">
		<?php $__env->startSection('panel4_panel_title', 'Hello World!'); ?>
		<?php $__env->startSection('panel4_panel_body'); ?>
		Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
		tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
		quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
		consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
		cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
		proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
		<?php $__env->stopSection(); ?>
		<?php echo $__env->make('MS::widgets.panel', array('class'=>'info', 'header'=> true, 'as'=>'panel4'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<?php $__env->startSection('panel5_panel_title', 'Warning'); ?>
		<?php $__env->startSection('panel5_panel_body'); ?>
		Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
		tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
		quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
		consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
		cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
		proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
		<?php $__env->stopSection(); ?>
		<?php echo $__env->make('MS::widgets.panel', array('class'=>'warning', 'header'=>true, 'as'=>'panel5'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<?php $__env->startSection('panel6_panel_title', 'Danger'); ?>
		<?php $__env->startSection('panel6_panel_body'); ?>
		Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
		tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
		quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
		consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
		cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
		proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
		<?php $__env->stopSection(); ?>
		<?php echo $__env->make('MS::widgets.panel', array('class'=>'danger', 'header'=>true, 'as'=>'panel6'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	</div>
	<div class="col-sm-12">
		<?php $__env->startSection('collapsible_panel_title', 'Collapsible Panel Group'); ?>
		<?php $__env->startSection('collapsible_panel_body'); ?>
		<?php echo $__env->make('MS::widgets.collapse', array('id'=>'1', 'class'=>'primary', 'header'=> 'This is a header', 'body'=>'Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo.','collapseIn'=>true), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<?php echo $__env->make('MS::widgets.collapse', array('id'=>'2', 'header'=> 'This is a header', 'body'=>'Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo.'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<?php echo $__env->make('MS::widgets.collapse', array('id'=>'3', 'class'=>'success', 'header'=> 'This is a header', 'body'=>'Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo.'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<?php $__env->stopSection(); ?>
		<?php echo $__env->make('MS::widgets.panel', array('header'=>true, 'as'=>'collapsible'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('MS::layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>