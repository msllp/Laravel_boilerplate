<?php /* E:\MS-Master\Projects\FrameworkPHP\MS-Frame_5_8\Master\vendor\msllp\core\src\Views/layouts/form/text.blade.php */ ?>
<?php
//class
$groupClass=["form-group"];
$labelClass=false;
$inputClass="form-control";
//Requiered
$required=false;
//perfix
$preFix=false;
$preFixClass="";
//perfic
$perFix=false;
$perFixClass="";
//value
$inputValue=false;
$editLock=false;

$vData=false;
//dd($data[]);
if(array_key_exists("vData",$data)){
//dd($data);


    if(array_key_exists("labelClass",$data['vData'])){
        $labelClass= $data['vData']['labelClass'];
        $vData['labelClass']=$data['vData']['labelClass'];
    }

    if(array_key_exists("inputClass",$data['vData'])){
        $inputClass= $inputClass." ".$data['vData']['inputClass'];
        $vData['inputClass']=$data['vData']['inputClass'];
    }
    if(array_key_exists("required",$data['vData'])){
        $required=$data['vData']['required'];
        $vData['required']=$data['vData']['required'];

        if($required && !in_array('input-group',$groupClass))$groupClass=array_merge($groupClass,['input-group']);
    }


    if(array_key_exists("preFix",$data['vData'])){
        $preFixClass=$preFixClass.$data['vData']['preFix'];
        $vData['preFix']=$data['vData']['preFix'];
        $preFix=true;
        if($preFix && !in_array('input-group',$groupClass))$groupClass=array_merge($groupClass,['input-group']);

    }

    if(array_key_exists("perFix",$data['vData'])){
        $perFixClass=$perFixClass.$data['vData']['perFix'];
        $vData['preFix']=$data['vData']['perFix'];
        $perFix=true;
        if($perFix && !in_array('input-group',$groupClass))$groupClass=array_merge($groupClass,['input-group']);

    }

    if(array_key_exists("groupClass",$data['vData'])){
        $groupClass=array_merge($groupClass,$data['vData']['groupClass']);

        $vData['groupClass']=$data['vData']['groupClass'];
    }

    // dd($groupClass);

}


if(array_key_exists("value",$data)){
    $inputValue=$data['value'];
//dd($data);

}

if(array_key_exists("editLock",$data)){
    $editLock=$data['editLock'];
//dd($data);

}


if(!array_key_exists("vName",$data)) $data['vName']=ucwords($data['name']);
if(!array_key_exists("desc",$data)) $data['desc']="Enter " . $data['vName'];
if(!array_key_exists("label",$data)) $data['label']=$data['vName'];
$data['vName']=ucwords($data['vName']);
//dd($groupClass);
?>


<?php if($vData && array_key_exists('labelClass',$vData)): ?>
    <label class="<?php echo e($labelClass); ?>"><?php echo e($data['label']); ?>

    </label>
<?php else: ?>
    <label><?php echo e($data['label']); ?></label>
<?php endif; ?>
<div class="<?php echo e(implode(" ", $groupClass)); ?>" title="<?php echo e($data['desc']); ?>">

    <?php if($preFix): ?>
        <span class="input-group-addon" title="Unit prefix"><i class="<?php echo e($preFixClass); ?>"></i></span>
    <?php endif; ?>

    <?php if($inputValue): ?>
        <?php if($editLock): ?>

            <?php echo $__env->make("MS::layouts.form.locked",['data'=>[
            'inputClass'=>$inputClass,
            'inputValue'=>$inputValue,
            'name'=>$data['name'],
            ]], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php else: ?>
            <input type="text" name="<?php echo e($data['name']); ?>" class="<?php echo e($inputClass); ?>" placeholder="Enter <?php echo e($data['vName']); ?> here" value=" <?php echo e($inputValue); ?>" >
        <?php endif; ?>
    <?php else: ?>
        <input type="text" name="<?php echo e($data['name']); ?>" class="<?php echo e($inputClass); ?>" placeholder="Enter <?php echo e($data['vName']); ?> here">
    <?php endif; ?>

    <?php if($perFix): ?>
        <span class="input-group-addon" title="Unit perfix"><i class="<?php echo e($perFixClass); ?>"></i></span>
    <?php endif; ?>

    <?php if($required): ?>
        <span class="input-group-addon" title="This Field is Required"><i class="text-danger fa fa-bullseye"></i></span>
    <?php endif; ?>

</div>
