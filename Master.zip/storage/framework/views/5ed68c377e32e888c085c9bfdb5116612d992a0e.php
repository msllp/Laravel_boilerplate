<?php /* E:\MS-Master\Projects\FrameworkPHP\gst_invoice\Master\MS\B\M/BM/V/genInvoice.blade.php */ ?>
<?php $__env->startSection('body'); ?>
<?php
/**
 * Created by PhpStorm.
 * User: ms
 * Date: 17-06-2019
 * Time: 03:51 AM
 */
?>

<msinvoice>






</msinvoice>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('MS::core.layouts.root', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>