<?php /* E:\MS-Master\Projects\FrameworkPHP\sfappbackend\latest\vendor\msllp\core\src\Views/core/layouts/rootJS.blade.php */ ?>

<?php echo $__env->yieldContent('body'); ?>

