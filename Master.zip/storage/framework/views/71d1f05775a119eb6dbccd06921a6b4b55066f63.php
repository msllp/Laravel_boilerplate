<?php /* E:\MS-Master\Projects\FrameworkPHP\sfappbackend\beta\vendor\msllp\core\src\Views/core/layouts/panel.blade.php */ ?>
<?php $__env->startSection('body'); ?>
    <div id="msapp">
<panelbackend></panelbackend>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('MS::core.layouts.root', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>