<?php /* E:\MS-Master\Projects\FrameworkPHP\sfappbackend\latest\vendor\msllp\core\src\Views/core/layouts/Form/input/oneline.blade.php */ ?>
<?php $__env->startSection('body'); ?>
<?php
//dd($data);
$array=[
    'name'=>$data['name'],
    'type'=>$data['input'],
    //'vName'=>$data['vName'],
    //'prefix'=>"lock text-info",
    //'perfix'=>"asterisk text-danger",
    //'inputOnly'=>true,
    //'required'=>true,
    'validation'=>[
        // 'minSize'=>5,
        'required'=>1
    ],
    //'inputClass'=>[],
    //'formClass'=>[],



];



$array=\MS\Core\Helper\MSForm::makeArrayForViewFromStyle($array,$data);


if (array_key_exists('vName',$data))$array['vName']=$data['vName'];
if (!array_key_exists('vName',$array))$array['vName']=$data['name'];

if(array_key_exists('style',$data)){



}

if(array_key_exists('validation',$data)){

if(array_key_exists( 'required',$data['validation']) && $data['validation'] ['required'])
    (array_key_exists('perfix',$array))?$array['perfix'].= " fa-asterisk text-danger":$array['perfix']= "asterisk text-danger";
if(array_key_exists('existIn',$data['validation']))dd(\MS\Core\Helper\MSForm::getDataFromTable($data['validation']['existIn']));

    //$array['']=;


}
//dd($array);

$arrayJson=collect($array)->toJson();

?>



    <inputtext :ms-data="<?php echo e($arrayJson); ?>" ref="<?php echo e($array['name']); ?>"    ></inputtext>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('MS::core.layouts.rootJS', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>