<?php /* E:\MS-Master\Projects\FrameworkPHP\sfappbackend\latest\vendor\msllp\core\src\Views/core/layouts/Form/formPlate.blade.php */ ?>
<?php $__env->startSection('body'); ?>



        <div class="alert alert-danger" v-if="mserrorCount" role="alert">
         <div v-for="error in mserror">
             <div v-for="msg in error.msg">
             {{ msg }}
             <br>
             </div>
         </div>

        </div>



        <form >
    <?php  echo $form  ?>
        </form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('MS::core.layouts.root', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>