<?php /* /HD/1/backend/sw/vendor/msllp/core/src/Views/core/layouts/HTML/splitButtonStart.blade.php */ ?>
<?php
/**
 * Created by PhpStorm.
 * User: ms
 * Date: 02-06-2019
 * Time: 02:22 PM
 */
//dd($data);
$uniqID="aa_".\MS\Core\Helper\Comman::random();
$uniqID2="bb_".\MS\Core\Helper\Comman::random();
?>





<div class="card">
    <div class="card-header collapse show " data-toggle="collapse" id="<?php echo e($uniqID2); ?>" data-target="#<?php echo e($uniqID); ?>" aria-expanded="false" aria-controls="<?php echo e($uniqID); ?>">
        <h4><?php echo e($data['title']); ?></h4>
    </div>
        <div class="collapse card card-body" id="<?php echo e($uniqID); ?>" aria-labelledby="<?php echo e($uniqID2); ?>" data-parent="#msapp">

