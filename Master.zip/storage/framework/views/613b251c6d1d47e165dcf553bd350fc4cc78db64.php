<?php /* E:\MS-Master\Projects\FrameworkPHP\sfappbackend\beta\MS\B\M/MAS/V/productAdd.blade.php */ ?>
<?php $__env->startSection('body'); ?>
    <?php
    $logo="logo_tr.png";

    if (isset($data) && array_key_exists('logo',$data))$logo=$data['logo'];


    $link=asset(implode('/',['images',$logo]));

    ?>
    <form class="form-signin card text-center ms-box" style="max-width: 100%" >
        <center  style="color: aliceblue; text-decoration-style: solid;">
            <h3 class="mb-3" >Add New Product</h3>
        </center>
        <div class="card-body" id="msapp">

            
            <div class="card-text" style="color: aliceblue;">
                              <?php

                $array=[
                    'name'=>"productName",
                    // 'type'=>"text",
                    'vName'=>"Product Name",

                    'prefix'=>"boxes text-info",
               //     'perfix'=>"asterisk text-danger",
                   // 'inputOnly'=>true,
                    'required'=>true,
                    'validation'=>[
                        'minSize'=>5,
                        'required'=>1
                    ],


                ];
                $arrayJson=collect($array)->toJson();

                ?>
                  <inputtext :ms-data="<?php echo e($arrayJson); ?>"     ></inputtext>




                <?php

                $array=[
                    'name'=>"ProductBuyRate",
                    //'type'=>"text",
                    'vName'=>"Buy Rate/Unit",

                    'prefix'=>"rupee-sign text-info",
                    //'perfix'=>"asterisk text-danger",
                  //  'inputOnly'=>true,
                    'required'=>true,
                    'validation'=>[
                        // 'type'=>'password',
                        //  'minSize'=>5,
                        'required'=>1
                    ],


                ];
                $arrayJson=collect($array)->toJson();

                ?>
                <inputtext :ms-data="<?php echo e($arrayJson); ?>"     ></inputtext>



                <div class="form-control">

                    <input type="file" />
                </div>


                <button class="btn btn-lg btn-primary btn-block card-link" type="submit"><i class="fa fa-plus-square"></i> Add Product</button>
                <p class="mt-2 text-muted card-subtitle">© 2017-2019</p>

            </div>

        </div>
        <div class="ms-copyright">  a Genuine <img src="<?php echo e(asset("images/m.png")); ?>" >illion certified Product </div>
    </form>

    <script type="text/javascript">



    </script>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('MS::core.layouts.root', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>