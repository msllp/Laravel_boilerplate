<?php /* E:\MS-Master\Projects\FrameworkPHP\MS-Frame_5_8\Master\vendor\msllp\core\src\Views/widgets/charts/clinechart.blade.php */ ?>

<canvas id="cline" width="350" height="220"></canvas>