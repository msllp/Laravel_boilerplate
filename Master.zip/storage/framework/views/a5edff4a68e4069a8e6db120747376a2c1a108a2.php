<?php $__env->startSection('body'); ?>
    <?php

    ?>

    <msgst ms-data="{}">






    </msgst>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('MS::core.layouts.root', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\MS-Master\Projects\FrameworkPHP\gst_invoice\Master\MS\B\M/BM/V/viewGST.blade.php ENDPATH**/ ?>