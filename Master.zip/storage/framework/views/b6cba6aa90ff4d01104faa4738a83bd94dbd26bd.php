<?php /* /HD/1/backend/sw/MS/B/M/MAS/V/productAdd.blade.php */ ?>
<?php $__env->startSection('body'); ?>

    <?php  echo $form  ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('MS::core.layouts.root', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>