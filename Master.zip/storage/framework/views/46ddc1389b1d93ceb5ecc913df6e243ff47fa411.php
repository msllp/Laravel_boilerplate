<?php /* /HD/1/backend/sw/vendor/msllp/core/src/Views/core/layouts/Form/button/buttonGroup.blade.php */ ?>
<?php
/**
 * Created by PhpStorm.
 * User: ms
 * Date: 05-06-2019
 * Time: 05:09 PM
 */
//dd($data);


?>

<div class="btn-group btn-block" role="group" aria-label="Basic example">

<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type =>$btnData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php // dd($btnData);

//$btnClass=[btn];
        $btn['Class']=['btn'];
        switch ($type){
    case 'back';
    $btn['Class'][]='btn-primary';
    break;

    case 'add';
                $btn['Class'][]='btn-success';
    break;

            case 'edit';
                $btn['Class'][]='btn-warning';
                break;


            case 'delete';
                $btn['Class'][]='btn-danger';
                break;
        }

//dd( route($btnData['route']));
?>

    <button type="button" v-on:click="getModBtn('<?php echo e(route($btnData['route'])); ?>')"   class="<?php echo e(implode(' ',$btn['Class'])); ?>"><?php echo e($btnData['btnText']); ?></button>


    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>



<script type="javascript">



</script>
