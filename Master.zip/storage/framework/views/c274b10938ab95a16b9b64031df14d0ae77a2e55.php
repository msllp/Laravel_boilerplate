<?php /* E:\MS-Master\Projects\FrameworkPHP\MS-Frame_5_8\Master\vendor\msllp\core\src\Views/documentation.blade.php */ ?>
<?php $__env->startSection('page_heading','Documentation'); ?>

<?php $__env->startSection('section'); ?>

		<?php $__env->startSection('dpanel_panel_title', 'Panel'); ?>
		<?php $__env->startSection('dpanel_panel_body'); ?>
			<?php $__env->startSection('inside_panel_title', 'Default title'); ?>
			<?php $__env->startSection('inside_panel_body'); ?>
				Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
			<?php $__env->stopSection(); ?>
			<?php echo $__env->make('MS::widgets.panel', array('header'=>true, 'as'=>'inside'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<?php $__env->stopSection(); ?>	
		<?php $__env->startSection('dpanel_panel_footer'); ?>
<pre class="codeWrapper">
<i class="fa fa-at"></i>section ('inside_panel_title', 'Default title')
<i class="fa fa-at"></i>section ('inside_panel_body')
&lt;p&gt;Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo&lt;/p&gt;
<i class="fa fa-at"></i>endsection
<i class="fa fa-at"></i>include('MS::widgets.panel', array('header'=>true, 'as'=>'inside'))
</pre>
		<?php $__env->stopSection(); ?>
		<?php echo $__env->make('MS::widgets.panel', array('class'=>'primary', 'header'=>true, 'footer'=>true, 'as'=>'dpanel'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


		
		<?php $__env->startSection('dcollapsible_panel_title', 'Collapssible'); ?>
		<?php $__env->startSection('dcollapsible_panel_body'); ?>
			<?php echo $__env->make('MS::widgets.collapse', array('id'=>'2', 'header'=> 'This is a header', 'body'=>'Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo.'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<?php $__env->stopSection(); ?>	
		<?php $__env->startSection('dcollapsible_panel_footer'); ?>
<pre class="codeWrapper">
<i class="fa fa-at"></i>include('MS::widgets.collapse', array('id'=>'2', 'header'=> 'This is a header', 'body'=>'Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo.'))
</pre>
		<?php $__env->stopSection(); ?>
		<?php echo $__env->make('MS::widgets.panel', array('class'=>'primary', 'header'=>true, 'footer'=>true, 'as'=>'dcollapsible'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

		

		<?php $__env->startSection('dbutton_panel_title', 'Button'); ?>
		<?php $__env->startSection('dbutton_panel_body'); ?>
			<?php echo $__env->make('MS::widgets.button', array('value'=>'Info button', 'class'=>'info'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
			<?php echo $__env->make('MS::widgets.button', array('class'=>'danger', 'size'=>'lg', 'value'=>'Large Button'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
			<?php echo $__env->make('MS::widgets.button', array('class'=>'success btn-outline', 'value'=>'Primary'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<?php $__env->stopSection(); ?>	
		<?php $__env->startSection('dbutton_panel_footer'); ?>
<pre class="codeWrapper">
<i class="fa fa-at"></i>include('MS::widgets.button', array('value'=>'Info button', 'class'=>'info'))
<i class="fa fa-at"></i>include('MS::widgets.button', array('class'=>'danger', 'size'=>'lg', 'value'=>'Large Button'))
<i class="fa fa-at"></i>include('MS::widgets.button', array('class'=>'success btn-outline', 'value'=>'Primary'))
</pre>
		<?php $__env->stopSection(); ?>
		<?php echo $__env->make('MS::widgets.panel', array('class'=>'primary', 'header'=>true, 'footer'=>true, 'as'=>'dbutton'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

		


		<?php $__env->startSection('doalert_panel_title', 'Alerts'); ?>
		<?php $__env->startSection('doalert_panel_body'); ?>
			<?php echo $__env->make('MS::widgets.alert', array('class'=>'success', 'message'=> 'You have an alert', 'icon'=> 'user'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
			<?php echo $__env->make('MS::widgets.alert', array('class'=>'info', 'dismissable'=>true, 'message'=> 'My message'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<?php $__env->stopSection(); ?>	
		<?php $__env->startSection('doalert_panel_footer'); ?>
<pre class="codeWrapper">
<i class="fa fa-at"></i>include('MS::widgets.alert', array('class'=>'success', 'message'=> 'You have an alert', 'icon'=> 'user'))
<i class="fa fa-at"></i>include('MS::widgets.alert', array('class'=>'info', 'dismissable'=>true, 'message'=> 'My message'))
</pre>
		<?php $__env->stopSection(); ?>
		<?php echo $__env->make('MS::widgets.panel', array('class'=>'primary', 'header'=>true, 'footer'=>true, 'as'=>'doalert'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

		

		<?php $__env->startSection('dprogress_panel_title', 'Progressbars'); ?>
		<?php $__env->startSection('dprogress_panel_body'); ?>
			<?php echo $__env->make('MS::widgets.progress', array('class'=> 'success', 'value'=>'44'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
			<?php echo $__env->make('MS::widgets.progress', array('animated'=> true, 'value'=>'72'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
			<?php echo $__env->make('MS::widgets.progress', array('class'=> 'danger', 'value'=>'12', 'badge'=>true), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<?php $__env->stopSection(); ?>	
		<?php $__env->startSection('dprogress_panel_footer'); ?>
<pre class="codeWrapper">
<i class="fa fa-at"></i>include('MS::widgets.progress', array('class'=> 'success', 'value'=>'44'))
<i class="fa fa-at"></i>include('MS::widgets.progress', array('animated'=> true, 'value'=>'72'))
<i class="fa fa-at"></i>include('MS::widgets.progress', array('class'=> 'danger', 'value'=>'12', 'badge'=>true))
</pre>
		<?php $__env->stopSection(); ?>
		<?php echo $__env->make('MS::widgets.panel', array('class'=>'primary', 'header'=>true, 'footer'=>true, 'as'=>'dprogress'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

	
<?php $__env->stopSection(); ?>

<?php echo $__env->make('MS::layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>