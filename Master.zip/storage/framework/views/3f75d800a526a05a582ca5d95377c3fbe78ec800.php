<?php /* E:\MS-Master\Projects\FrameworkPHP\MS-Frame_5_8\Master\vendor\msllp\core\src\Views/layouts/form/locked.blade.php */ ?>
<?php
/**
 * Created by PhpStorm.
 * User: ms
 * Date: 24-03-2019
 * Time: 05:04 AM
 */
$inputClass=$data['inputClass'];
$inputValue=$data['inputValue'];


?>


<input type="text" class="<?php echo e($inputClass); ?>" value="<?php echo e($inputValue); ?>" disabled>
<input type="hidden" name="<?php echo e($data['name']); ?>" class="<?php echo e($inputClass); ?>" value="<?php echo e($inputValue); ?>" disabled>
