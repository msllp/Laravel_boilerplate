{
  "name": "sb-admin-laravel-2",
  "version": "0.0.0",
  "authors": [
    "sankhadeep <sankhadeep@sahusoft.com>"
  ],
  "license": "MIT",
  "private": true,
  "ignore": [
    "**/.*",
    "node_modules",
    "bower_components",
    "test",
    "tests"
  ],
  "dependencies": {
    "jquery": "~2.1.3",
    "fontawesome": "~4.3.0",
    "Chart.js": "~1.0.2",
    "metisMenu": "~1.1.3"
  }
}
