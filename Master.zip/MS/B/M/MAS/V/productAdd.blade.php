@extends('MS::core.layouts.root')
@section('body')

    <?php  echo $form  ?>


@endsection
