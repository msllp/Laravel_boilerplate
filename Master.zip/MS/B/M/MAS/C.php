<?php

namespace B\MAS;

use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Http\Request;
use Razorpay\Api;

class C extends BaseController
{
    use  DispatchesJobs, ValidatesRequests;


    protected $data=
        [
            'logo'=>"logo-a.png"

        ];


    public function genInvFroApp(){
        return view("BM.V.genInvoice");
    }
    public function index(Request $r){


//        //dd($r->all());
//        header("Access-Control-Allow-Origin: *");
//        $input=$r->all();
//
//        $url = "https://books.zoho.com/api/v3/meta/hsnsaccodes?search_text=".$input['hsn']; // http://localhost:8000/template/1/11
//        $html =  file_get_contents($url)  ;

        return view("BM.V.viewGST");


       // dd($html)  ;
        return $html;
      //  $html =  file_get_contents($url) .$style ;
        //dd($html);
        //return $html;
       //return view("BM.V.genInvoice");

        $pdf = \PDF::loadView('BM.V.genInvoice');
       // dd($pdf);
        return $pdf->download('invoice.pdf');
        $link=\MS\Core\Helper\MSPay::makePaymentLink(100,['customerEmail'=>'maxirooney@millionsllp.com',"customerNumber"=>"9662611234",'description'=>"Test From Class"]);
        return redirect($link['link']);
        $id="rzp_test_hWAPfGnN0KwMXK";
        $secret="f2CxU8JV3aWiTAjMY2X5y630";
        $razorPay=new Api\Api($id,$secret);

        $razorPayMaster=$razorPay->invoice->create(
            [
                'type' => 'link',
                'amount' =>6000,
                'description' => 'For MSLLP Test purpose Test',
                'customer' => [
                    'email' => 'mitul@millionsllp.com',
                    "contact"=> "9662611234",
                ],

            ]
        );



        dd(
         $razorPayMaster->notifyBy('sms')   );


        $r=$r->all();
//dd($r);
        if(array_key_exists('dataLink',$r) && $r['dataLink']){

            return response()->json([
                [
                    'name'=>'ProductName',
                    'msg'=>["erroe"]
                    

                ]


            ],422);

        }

        //dd(B::getTable());

        //return view("MS::core.layouts.login");
        //$m=new \MS\Core\Helper\MSDB(__NAMESPACE__,'anuj_test');


       // $code=\MS\Core\Helper\Comman::encode("mitul");

     //   dd(\MS\Core\Helper\Comman::decode($code));

        return view("BM.V.genInvoice");

        $m=new \MS\Core\Helper\MSDB("B\BM","Master_Booking",[]);
        //$m->migrate();
        return $m->displayFrom();

        //return view("MS::core.layouts.login")->with('data',$this->data);

    }

    public function productAddForm(Request $r){

        return $this->index($r);

        return view("MAS.V.productAdd")->with('data',$this->data);

    }

    public function prdocutAdd(){


        $m=new \MS\Core\Helper\MSDB("B\HM","Master_Product",[]);
        dd($m->model->migrate());
        dd($m->displayFrom()->reder());

    }

public function genarateInvoicePDF(Request $r){




       return view("BM.V.pdfInvoice");
    $pdf = \PDF::loadView('BM.V.pdfInvoice');
    return $pdf->setPaper('a4', 'landscape')->download('invoice.pdf');


}

public function findGst(Request $r){
    //header("Access-Control-Allow-Origin: *");
    $input=$r->all();


    $url = "https://books.zoho.com/api/v3/meta/hsnsaccodes?search_text=".urlencode ($input['key']); // http://localhost:8000/template/1/11
    $html =  file_get_contents($url)  ;
    $jdata=json_decode($html,true);
    return response()->json($jdata,200);

    return $html;
}

    public function findGstRate(Request $r){
        //header("Access-Control-Allow-Origin: *");
        $input=$r->all();

        $url = "https://www.paisabazaar.com/index.php"; // http://localhost:8000/template/1/11
        $html =  file_get_contents($url)  ;
        $url = "https://www.paisabazaar.com/wp-admin/admin-ajax.php?action=gst_ajax_action&text=".urlencode ($input['key']); // http://localhost:8000/template/1/11
        $html =  file_get_contents($url)  ;
        $jdata=json_decode($html,true);
        dd($jdata);
        return response()->json($jdata,200);

        return $html;
    }




}
