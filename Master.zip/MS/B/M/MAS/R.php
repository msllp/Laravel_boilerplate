<?php
/**
 * Created by PhpStorm.
 * User: ms
 * Date: 11-05-2019
 * Time: 03:49 AM
 */


\MS\Core\Helper\Comman::load_Route("B\MAS");
