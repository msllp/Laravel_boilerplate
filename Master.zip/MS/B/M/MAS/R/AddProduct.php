<?php
/**
 * Created by PhpStorm.
 * User: ms
 * Date: 02-06-2019
 * Time: 01:27 PM
 */

namespace B\MAS\R;



class AddProduct extends MS\Core\Helper\Request\BaseMaster
{

}
