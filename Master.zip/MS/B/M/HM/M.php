<?php
/**
 * Created by PhpStorm.
 * User: ms
 * Date: 26-05-2019
 * Time: 07:28 PM
 */

namespace B\HM;


use MS\Core\Model\Master;


class M  extends Master
{

}
