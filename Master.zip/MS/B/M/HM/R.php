<?php
/**
 * Created by PhpStorm.
 * User: ms
 * Date: 26-05-2019
 * Time: 07:28 PM
 */
\MS\Core\Helper\Comman::load_Route("B\HM");
