<?php
/**
 * Created by PhpStorm.
 * User: ms
 * Date: 26-05-2019
 * Time: 07:27 PM
 */

namespace B\HM;


class C
{
public function addProductPost(){

}
}
