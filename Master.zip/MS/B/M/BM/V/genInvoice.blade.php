@extends('MS::core.layouts.root')
@section('body')
<?php
/**
 * Created by PhpStorm.
 * User: ms
 * Date: 17-06-2019
 * Time: 03:51 AM
 */
?>

<msinvoice>






</msinvoice>
    @endsection
