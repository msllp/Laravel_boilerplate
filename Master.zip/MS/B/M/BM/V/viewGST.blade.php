@extends('MS::core.layouts.root')
@section('body')
    <?php

    ?>

    <msgst ms-data="{}">






    </msgst>
@endsection
